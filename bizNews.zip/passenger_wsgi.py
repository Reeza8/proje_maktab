import bizNews.wsgi

application=bizNews.wsgi.application
